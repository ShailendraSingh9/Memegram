from django.db import models
from django.db.models.deletion import CASCADE
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, RegexValidator

# Create your models here.
class MyProfile(models.Model):
    name=models.CharField(max_length=100)
    user= models.OneToOneField(to=User, on_delete=CASCADE  )
    age=models.IntegerField(default=18, validators=[MinValueValidator(18)])
    bio=models.TextField(null=True, blank=True)
    phone=models.CharField(validators=[RegexValidator("^0?[5-9]{1}\d{9}$")], max_length=13, null=True, blank=True)
    picture=models.ImageField(upload_to= "images", null=True)
    address=models.TextField(null=True, blank=True)
    status=models.CharField(max_length=20, default="single", choices=(("single","single"), ("married","married"), ("engaged","engaged"), ("complicated","complicated")))
    gender=models.CharField(max_length=20, default="select", choices=(("male","male"), ("female","female"),("others","others")))
    def __str__(self):
        return "%s" % self.user

class MyPost(models.Model):
    post = models.ImageField(upload_to= "images", null=True)
    subject=models.CharField(max_length=200)
    msg=models.TextField(null=True, blank=True)
    cr_date=models.DateTimeField(auto_now_add=True)
    uploaded_by= models.ForeignKey(to=MyProfile, on_delete=CASCADE , null=True )
    def __str__(self):
        return "%s" % self.subject

class PostComment(models.Model):
    post=models.ForeignKey(to=MyPost, on_delete=CASCADE)
    commented_by= models.ForeignKey(to=MyProfile, on_delete=CASCADE  )
    msg=models.TextField(null=True, blank=True)
    cr_date=models.DateTimeField(auto_now_add=True)
    flag=models.CharField(max_length=20, null=True, blank=True, choices=(("racist","racist"), ("abusive","abusive"),("hateful","hateful")))
    def __str__(self):
        return "%s" % self.msg


class PostLike(models.Model):
    post=models.ForeignKey(to=MyPost, on_delete=CASCADE)
    liked_by= models.ForeignKey(to=MyProfile, on_delete=CASCADE  )
    cr_date=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return "%s" % self.liked_by

class FollowUser(models.Model):
    followed_by=models.ForeignKey(to=MyProfile, on_delete=CASCADE, related_name="profile_name")
    profile= models.ForeignKey(to=MyProfile, on_delete=CASCADE,  related_name="followed_by" )
    def __str__(self):
        return "%s is followed by %s" % (self.profile, self.followed_by)

class PostReport(models.Model):
    post=models.ForeignKey(to=MyPost, on_delete=CASCADE)
    reported_by= models.ForeignKey(to=MyProfile, on_delete=CASCADE  )
    cr_date=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return "%s" % self.reported_by
