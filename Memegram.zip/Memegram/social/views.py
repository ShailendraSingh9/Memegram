from django.shortcuts import render,redirect
from django.views.generic.list import ListView
from django.views.generic.base import TemplateView
from django.views.generic.edit import CreateView , UpdateView , CreateView ,DeleteView
from django.views.generic.list import ListView
from social.models import FollowUser,MyPost,MyProfile,PostComment,PostLike ,PostReport
from django.views.generic.detail import DetailView
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.http.response import HttpResponseRedirect
from django.db.models import Q
from bs4 import BeautifulSoup as BSoup
import requests

# Create your views here.


@method_decorator(login_required, name="dispatch")

class HomeView(TemplateView):
    template_name="social/home.html"
    def get_context_data(self, **kwargs):
        context=TemplateView.get_context_data(self,**kwargs)
        followedList = FollowUser.objects.filter(followed_by=self.request.user.myprofile)
        followedList2 = []
        for e in followedList:
            followedList2.append(e.profile)
        si = self.request.GET.get("si")

        if si == None:
            si = ""
        posts= MyPost.objects.filter(Q(uploaded_by__in = followedList2)).filter(Q(subject__icontains =si) | Q(msg__icontains = si)).order_by("-id")
        profiles= MyProfile.objects.filter(Q(name__icontains =si) | Q(phone__icontains = si))
        for p1 in profiles:
            p1.followed = False
            ob = FollowUser.objects.filter(profile=p1, followed_by=self.request.user.myprofile)
            if ob:
                p1.followed=True

        for p1 in posts:
            p1.liked = False
            ob = PostLike.objects.filter(post=p1, liked_by=self.request.user.myprofile)
            if ob:
                p1.liked=True
        for p1 in posts:
            if posts:
                ob = PostLike.objects.filter(post=p1)
                p1.likecount = ob.count()

        for p1 in posts:
            if posts:
                p1.reported=False
                ob=PostReport.objects.filter(post=p1, reported_by = self.request.user.myprofile)
                if ob:
                    p1.reported = True

        for p1 in posts:
            if posts:
                p1.commented=False
                ob=PostComment.objects.filter(post=p1, commented_by = self.request.user.myprofile)
                if ob:
                    p1.commented = True
        context["mypost_list"] = posts
        context["myprofile_list"] = profiles
        return context


@method_decorator(login_required, name="dispatch")
class AboutView(TemplateView):
    template_name="social/about.html"

class ContactView(TemplateView):
    template_name="social/contact.html"

class WelcomeView(TemplateView):
    template_name="social/welcome.html"

def follow(req , pk):
    user=MyProfile.objects.get(pk=pk)
    FollowUser.objects.create(profile = user, followed_by = req.user.myprofile)
    return HttpResponseRedirect(redirect_to = "/social/myprofile")

def unfollow(req , pk):
    user=MyProfile.objects.get(pk=pk)
    FollowUser.objects.filter(profile = user, followed_by = req.user.myprofile).delete()
    return HttpResponseRedirect(redirect_to = "/social/myprofile")


def like(req , pk):
    post=MyPost.objects.get(pk=pk)
    PostLike.objects.create(post = post, liked_by = req.user.myprofile)
    return HttpResponseRedirect(redirect_to = "/social/home")

def unlike(req , pk):
    post=MyPost.objects.get(pk=pk)
    PostLike.objects.filter(post = post, liked_by = req.user.myprofile).delete()
    return HttpResponseRedirect(redirect_to = "/social/home")

def report(req , pk):
    post=MyPost.objects.get(pk=pk)
    PostReport.objects.create(post = post, reported_by = req.user.myprofile)
    return HttpResponseRedirect(redirect_to = "/social/home")
def comment(req , pk):
    post=MyPost.objects.get(pk=pk)
    msg=PostComment.objects.all().filter(post = post, commented_by = req.user.myprofile)
    return render(request , '/social/mypost/<int:pk>',{'post':post,'comments':msg} )
@method_decorator(login_required, name="dispatch")
class MyProfileUpdateView(UpdateView):
    model=MyProfile
    fields=["name","age","status","gender", "phone","picture","bio","address"]

@method_decorator(login_required, name="dispatch")
class MyPostCreate(CreateView):
    model= MyPost
    fields=["subject","msg", "post"]
    def form_valid(self , form):
        self.object =   form.save()
        self.object.uploaded_by = self.request.user.myprofile
        self.object.save()
        return HttpResponseRedirect(self.get_success_url())
@method_decorator(login_required, name="dispatch")
class MyPostListView(ListView):
    model= MyPost
    def get_queryset(self):
        si = self.request.GET.get("si")
        if si == None:
            si = ""
        return MyPost.objects.filter(Q(uploaded_by = self.request.user.myprofile)).filter(Q(subject__icontains =si) | Q(msg__icontains = si)).order_by("-id")

@method_decorator(login_required, name="dispatch")
class MyPostDetailView(DetailView):
    model= MyPost

@method_decorator(login_required, name="dispatch")
class MyPostDeleteView(DeleteView):
    model= MyPost

@method_decorator(login_required, name="dispatch")
class MyProfileListView(ListView):
    model= MyProfile
    def get_queryset(self):
        ai = self.request.GET.get("ai")
        if ai == None:
            ai = ""
        profileList = MyProfile.objects.filter(Q(name__icontains =ai) | Q(phone__icontains = ai))
        for p1 in profileList:
            p1.followed = False
            ob = FollowUser.objects.filter(profile=p1, followed_by=self.request.user.myprofile)
            if ob:
                p1.followed=True
        return profileList

@method_decorator(login_required, name="dispatch")
class MyProfileDetailView(DetailView):
    model= MyProfile
    def get_context_data(self, **kwargs):
        context=DetailView.get_context_data(self,**kwargs)
        si = self.request.GET.get("si")

        if si == None:
            si = ""
        posts= MyPost.objects.filter(Q(uploaded_by = self.request.user.myprofile)).filter(Q(subject__icontains =si) | Q(msg__icontains = si)).order_by("-id")
        for p1 in posts:
            p1.liked = False
            ob = PostLike.objects.filter(post=p1, liked_by=self.request.user.myprofile)
            if ob:
                p1.liked=True
        for p1 in posts:
            if posts:
                ob = PostLike.objects.filter(post=p1)
                p1.likecount = ob.count()
        context["mypost_list"] = posts

        return context
